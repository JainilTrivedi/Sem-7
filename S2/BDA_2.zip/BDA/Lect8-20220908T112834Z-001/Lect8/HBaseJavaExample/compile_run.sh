javac -cp `hbase classpath` Example.java
java Example
